//(function(){
//    function go(){
//        $('#btn').click(function(){
//           var msg = $('#text').val(); 
//           alert(msg);
//        });
//    }
//
//})();
$('#btn').click(function () {
	var msg = $('#text').val();
	alert(msg);
});